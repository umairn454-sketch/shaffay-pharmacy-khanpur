SHAFFAY PHARMACY KHANPUR — WEBSITE STARTER

Files:
- index.html: responsive, professional one-page website

HOW TO PREVIEW
1. Open index.html in a browser.
2. On Android, you can upload this file to a static website host from your phone or computer.

BEFORE GOING LIVE
1. Open index.html in a text editor.
2. Find: const PHARMACY_WHATSAPP_NUMBER = "923084770517";
3. WhatsApp number has been set to 923084770517 based on the number provided.
   Example format: 923001234567 (example only; do not use unless it is your number).
4. Replace the location section with the shop's exact address and update phone contact.
5. Add actual products, prices and stock only after confirming them.
6. Do not list prescription-only medicines as freely purchasable; comply with local pharmacy and e-commerce rules.

FREE HOSTING OPTIONS
- GitHub Pages can host static HTML sites for free. Create a repository, upload index.html, enable Pages in repository settings.
- Netlify also offers a free tier for static sites; check its current plan limits.

LIMITATIONS
This is a front-end starter site. It does not include a real inventory database, admin login, online payments, delivery integration, or secure order storage. The order form opens WhatsApp only after a valid shop number is configured. A custom domain and Google Play Store publishing may cost money.
